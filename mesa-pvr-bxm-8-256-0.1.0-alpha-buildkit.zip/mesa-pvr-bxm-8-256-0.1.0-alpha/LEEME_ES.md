# Kit de compilación — driver PowerVR BXM-8-256 (0.1.0-alpha)

Este es el proyecto original con **tres cambios** para que se pueda compilar sin instalar nada
en tu PC (se compila en los servidores gratuitos de GitHub):

1. `tools/setup_mesa.sh` corregido. El original aplicaba los parches sobre "Mesa 25.0.0", pero
   los parches son de octubre de 2026 y tocan archivos que solo existen en Mesa 26+. Ahora el
   script busca solo una base de Mesa donde los 5 parches apliquen y guarda cuál en `BASE_COMMIT.txt`.
2. `.github/workflows/build-and-release.yml` reescrito. El original dependía de un submódulo que
   no existe al subir el zip a un repositorio nuevo. El nuevo clona Mesa, aplica parches,
   compila las herramientas nativas, compila para Android y sube los zips (y los logs).
3. Este archivo.

## Estado real (léelo antes de usarlo)

- **No lo he podido compilar yo** (mi entorno no tiene internet). El proceso de compilación
  está sin probar: es posible que falle la primera vez por algún paquete o versión.
  Si falla, descarga los logs (ver abajo) y mándamelos.
- **El driver nunca se ha ejecutado en un teléfono.** Según los documentos del autor, una sonda
  anterior provocó un kernel panic y las pruebas en hardware están suspendidas. Que compile
  no significa que funcione.
- Está hecho para el kernel de GPU `25.1@6715691` (Redmi Note 14 5G, Android 16).

## Compilar (sin instalar nada)

1. Crea una cuenta en github.com y un repositorio **privado** nuevo.
2. Sube **todo el contenido de esta carpeta** (Add file > Upload files).
   - Las carpetas que empiezan por punto (`.github`) a veces no se suben al arrastrar. Si en tu
     repo no aparece `.github/workflows/`, crea el archivo a mano: Add file > Create new file,
     nómbralo `.github/workflows/build.yml` y pega el contenido de `WORKFLOW-para-GitHub.yml`.
3. Pestaña **Actions** > "Compilar driver PowerVR BXM-8-256" > **Run workflow**.
4. Tarda entre 20 y 60 minutos. Al terminar (en verde), abre la ejecución y descarga el
   artefacto **bxm8256-driver**. Dentro estarán:
   - `vulkan_pvr_bxm8256_adrenotools.zip` (para el gestor de drivers de Eden/Azahar; no lo extraigas)
   - `vulkan_pvr_bxm8256_icd.zip` (para contenedores tipo Winlator)
5. Si sale en rojo: en esa ejecución descarga igualmente el artefacto (trae los logs) y copia el
   mensaje del paso que falló. Mándamelos y lo corregimos.

## Antes de instalar el driver en el teléfono

1. Instala **Vulkan Caps Viewer** y mira el campo `driverInfo` de tu GPU. Debe decir
   **`25.1@6715691`**. Si dice otra cosa, **no lo uses**: el driver habla con el kernel con
   estructuras exactas de esa versión y un desajuste es lo que causó el kernel panic del autor.
2. Primera prueba: batería por encima del 50 %, sin otras apps abiertas, y con algo que puedas
   perder sin problema. Si el teléfono se reinicia o se congela, para ahí y no insistas.
3. No ejecutes `tools/pvr_connect_probe.c`: está bloqueado a propósito con `#error`.

## Compilar en tu propio Linux (alternativa)

```bash
export ANDROID_NDK_ROOT=/ruta/a/android-ndk-r27c
./tools/setup_mesa.sh      # clona Mesa y aplica parches
# luego, los mismos pasos del workflow (herramientas nativas) y:
./tools/build_driver.sh
```
